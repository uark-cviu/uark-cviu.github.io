#include <graph.hpp>
#include <queue>


std::vector<int> searchShortestPath(Graph &G, int start, int destination) {
    // YOUR CODE HERE
}


