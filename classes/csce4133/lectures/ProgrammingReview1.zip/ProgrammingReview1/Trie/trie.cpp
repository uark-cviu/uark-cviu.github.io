#include <iostream>
#include <string>
#include <vector>

#define MAX 26

struct Node {
    std::string word;
    Node *parent;
    Node *children[MAX];
    Node();
    ~Node();
};

Node::Node() {
    this->parent = NULL;
    for (int i = 0; i < MAX; ++i)
        this->children[i] = NULL;
}

Node::~Node() {
    this->parent = NULL;
    for (int i = 0; i < MAX; ++i)
        this->children[i] = NULL; // If we declare delete this->children[i], it will recursively call the deconstructor. In some cases, we do not want this phonomenan
}

class Dictionary {
    private:
        Node *root;
        void release(Node *p);
        int size(Node *p);
        Node* insert(Node *p, int height, std::string word);
        void printAllInOrder(Node *p);
    public:
        Dictionary();
        ~Dictionary();
        int size();
        bool exist(std::string word);
        void insert(std::string word);
        void printAllInOrder();
};

Dictionary::Dictionary() {
    std::cout << "Create an empty dictionary" << std::endl;
    this->root = new Node();
}

Dictionary::~Dictionary() {
    std::cout << "The deconstructor is called" << std::endl;
    this->release(this->root);
}

void Dictionary::release(Node *p) {
    if (p == NULL)
        return;
    for (int i = 0; i < MAX; ++i)
        this->release(p->children[i]);
    if (p->word.size() > 0)
        std::cout << "Remove " << p->word << " out of dictionary" << std::endl;
    delete p;
    p = NULL;
}

int Dictionary::size(Node *p) {
    if (p == NULL)
        return 0;
    int cnt = (p->word.size() > 0) ? 1 : 0;
    for (int i = 0; i < MAX; ++i)
        cnt += this->size(p->children[i]);

    //std::cout << "Node: " << p->word<< ", Count: " << cnt << std::endl;
    return cnt;
}

int Dictionary::size() {
    return this->size(this->root);
}

bool Dictionary::exist(std::string word) {
    Node *p = this->root;
    for (int i = 0; i < word.size() && p != NULL; ++i) {
        p = p->children[word[i] - 'a'];
    }
    return (p != NULL && p->word == word); 
}

void Dictionary::insert(std::string word) {
    std::cout << "Insert " << word << " into dictionary" << std::endl;
    this->root = this->insert(this->root, 0, word);
}

Node* Dictionary::insert(Node *p, int height, std::string word) {
    if (p != NULL && p->word == word) {
        std::cout << word << " has been already existed in the dictionary" << std::endl;
        return p;
    }
    if (p == NULL)
        p = new Node();
    if (height == word.size()) { // insert new word into dictionary
        p->word = word;
        return p;
    } else {
        Node *q = this->insert(p->children[word[height] - 'a'], height + 1, word);
        p->children[word[height] - 'a'] = q;
        q->parent = p;
    }
    return p;
}

void Dictionary::printAllInOrder() {
    std::cout << "The dictionary consists of:";
    this->printAllInOrder(this->root);
    std::cout << std::endl;
}

void Dictionary::printAllInOrder(Node *p) {
    if (p == NULL)
        return;
    if (p->word.size() != 0)
        std::cout << " " << p->word;
    for (int i = 0; i < MAX; ++i)
        this->printAllInOrder(p->children[i]);
}

int main() {
    Dictionary dict;

    std::cout << std::endl;

    dict.insert("hello");
    dict.insert("hi");
    dict.insert("apple");
    dict.insert("organe");
    dict.insert("worm");
    dict.insert("dog");
    dict.insert("cat");
    dict.insert("dolphin");
    dict.insert("mango");
    dict.insert("apple");

    std::cout << std::endl;

    std::cout << "There is " << dict.size() << " words in the dictionary" << std::endl;

    std::cout << std::endl;
    
    std::cout << "Is the word of 'apple' in the dictionary? " << (dict.exist("apple") ? "Yes" : "No") << std::endl;
    std::cout << "Is the word of 'mango' in the dictionary? " << (dict.exist("mango") ? "Yes" : "No") << std::endl;
    std::cout << "Is the word of 'dog' in the dictionary? " << (dict.exist("dog") ? "Yes" : "No") << std::endl;

    std::cout << std::endl;

    dict.printAllInOrder();

    std::cout << std::endl;
}
