// Hello World.cpp
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <pthread.h>
#include <opencv2/opencv.hpp>

void* printOpenCVVersion(void *vargp) {
  sleep(1);
  std::cout << "OpenCV version : "; 
  std::cout << CV_VERSION << std::endl;
  return NULL;
}

int main() {
  pthread_t thread_id;
  pthread_create(&thread_id, 
		NULL, 	
		printOpenCVVersion, 
		NULL);
  pthread_join(thread_id, NULL);
  exit(0);
}

