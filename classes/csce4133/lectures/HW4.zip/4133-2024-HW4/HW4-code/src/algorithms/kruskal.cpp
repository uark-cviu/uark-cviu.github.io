#include <graph.hpp> 
#include <sort.hpp> 


std::vector<Edge> constructMSTKruskal(Graph G) {
    std::vector<Edge> edges = G.exportEdges(); // Graph's edges
    // YOUR CODE HERE
}

