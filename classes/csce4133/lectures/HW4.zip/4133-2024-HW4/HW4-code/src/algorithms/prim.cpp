#include <graph.hpp> 
#include <sort.hpp> 
#include <queue>


std::vector<Edge> constructMSTPrim(Graph G) {
    // YOUR CODE HERE

}

