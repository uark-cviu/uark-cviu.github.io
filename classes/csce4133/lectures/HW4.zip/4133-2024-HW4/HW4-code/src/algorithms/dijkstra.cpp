#include <graph.hpp>
#include <queue>



std::vector<int> searchShortestPath(Graph &G, int start, int passBy, int destination) { 
    // YOUR CODE HERE   
}
