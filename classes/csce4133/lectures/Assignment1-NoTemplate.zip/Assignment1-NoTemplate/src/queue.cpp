#include <queue.hpp>


QueueNode::QueueNode(int value, QueueNode *next, QueueNode *prev) {
    this->value = value;
    this->next = next;
    this->prev = prev;
}


QueueNode::~QueueNode() {
    this->next = this->prev = NULL;
}


Queue::Queue() {
    this->head = this->tail = NULL;
}


Queue::~Queue() {
    QueueNode *p = this->head;
    while (p != NULL) {
        QueueNode *q = p->next;
        delete p;
        p = q;
    }
    this->head = this->tail = NULL;
}


bool Queue::empty() {
    if (this->head == NULL && this->tail == NULL)
        return true;
    else
        return false;
}


int Queue::pop() {
    int value = this->head->value;

    QueueNode *p = this->head;
    if (p->next == NULL)
        this->head = this->tail = NULL;
    else
        this->head = p->next;
    delete p;

    return value;
}


void Queue::push(int value) {
    QueueNode *p = new QueueNode(value, NULL, NULL);
    if (this->tail == NULL) {
        this->head = this->tail = p;
    } else {
        this->tail->next = p;
        p->prev = this->tail;
        this->tail = p;
    }
}

