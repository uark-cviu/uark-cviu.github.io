#include <stack.hpp>


StackNode::StackNode(int value, StackNode *next) {
    this->value = value;
    this->next = next;
}


StackNode::~StackNode() {
    this->next = NULL;
}


Stack::Stack() {
    this->head = NULL;
}


Stack::~Stack() {
    // YOUR CODE HERE
}


bool Stack::empty() {
    // YOUR CODE HERE
}


int Stack::pop() {
    // YOUR CODE HERE
}


void Stack::push(int value) {
    // YOUR CODE HERE
}
