#include <linked_list.hpp>


LinkedListNode::LinkedListNode(int value, LinkedListNode* next, LinkedListNode* prev) {
    this->value = value;
    this->next = next;
    this->prev = prev;
}


LinkedListNode::~LinkedListNode() {
    this->next = NULL;
}



LinkedList::LinkedList() {
     this->root = NULL;
}


LinkedList::~LinkedList() {
    // YOUR CODE HERE
}



LinkedListNode* LinkedList::insert(int value) {
    // YOUR CODE HERE
}


LinkedListNode* LinkedList::find(int value) {
    // YOUR CODE HERE
}


LinkedListNode* LinkedList::getRoot() {
    return this->root;
}




LinkedListNode* LinkedList::remove(int value) {
    // YOUR CODE HERE
}



int LinkedList::size() {
    // YOUR CODE HERE
}

