#pragma once
#include <iostream>


struct QueueNode {
    int value;
    QueueNode *next;
    QueueNode *prev;

    QueueNode(int value, QueueNode *next, QueueNode *prev);
    ~QueueNode();
};


class Queue {
    private:
        QueueNode *head;
        QueueNode *tail;
    public:
        Queue();
        ~Queue();

        bool empty();
        int pop();
        void push(int value);
};
