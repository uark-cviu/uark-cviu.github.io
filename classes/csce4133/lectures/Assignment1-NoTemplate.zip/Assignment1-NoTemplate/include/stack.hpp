#pragma once
#include <iostream>


struct StackNode {
    int value;
    StackNode *next;

    StackNode(int value, StackNode *next);
    ~StackNode();
};

class Stack {
    private:
        StackNode *head;
    public:
        Stack();
        ~Stack();

        bool empty();
        int pop();
        void push(int value);
};
