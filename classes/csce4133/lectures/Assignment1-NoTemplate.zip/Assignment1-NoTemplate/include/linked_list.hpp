#pragma once
#include <iostream>


struct LinkedListNode {
    int value;
    LinkedListNode *next;
    LinkedListNode *prev;
    LinkedListNode(int value = 0, LinkedListNode* next = NULL, LinkedListNode *prev = NULL);
    ~LinkedListNode();
};


class LinkedList {
    private:
         LinkedListNode *root;
    public:
         LinkedList();
         ~LinkedList();

         LinkedListNode* insert(int value);
         LinkedListNode* find(int value);
         LinkedListNode* remove(int value);
         int size();

         LinkedListNode* getRoot();
};


