#include <iostream>
#include <string>
#include <vector> 
#include <array_value.hpp>

extern std::string sortAlgName;

void sort(std::vector<ArrayValue> &array, int l, int r);
