#include <vector>

struct Edge {
    int u; int v; int w;
    Edge();
    Edge(int u, int v, int w);
    Edge(const Edge &e);
    bool operator<(const Edge &second);
    bool operator>(const Edge &second);
    bool operator==(const Edge &second);
    bool operator<=(const Edge &second);
    bool operator>=(const Edge &second);
};

class Graph {
  public:
    int n; // Number of vertices 
    std::vector<std::vector<Edge> > e; // Adjacent list 
    Graph(int n);
    ~Graph();
    void insertEdge(int u, int v, int w, bool directed = false);
    std::vector<Edge> exportEdges();
};

class DisjointSet {
    private:
        std::vector<int> parent;
        int find(int u);
    public:
        DisjointSet(int n);
        int isOnSameSet(int u, int v);
        void join(int u, int v);
};

Graph loadTestGraph();

Graph loadCampusGraph();

template<class T>
void sort(std::vector<T> &array, int l, int r);
