#include <graph.hpp>
#include <iostream>

std::vector<Edge> constructMSTKruskal(Graph G) {
    std::vector<Edge> edges = G.exportEdges(); 
    std::vector<Edge> MST;
    DisjointSet T(G.n); 
    int size_of_edges = edges.size();
    sort(edges, 0, size_of_edges - 1); 
    for (auto e: edges) {
        int u = e.u;
        int v = e.v;
        int w = e.w;
        if (T.isOnSameSet(u, v) == false) {
            T.join(u, v);
            MST.push_back(Edge(u, v, w));
        }
    }
    return MST;
}


void performTest(Graph G, std::string graphName) {
    std::vector<Edge> MST;
    MST = constructMSTKruskal(G);
    int total = 0;
    for (auto e: MST)
        total += e.w;

    std::cout << "Total Cost of MST in " << graphName << ": " << total << std::endl;
    std::cout << "List of Edges in MST: " << std::endl;
    for (auto e: MST)
        std::cout << "(" << e.u << ", " << e.v << ", " << e.w << ") ";
    std::cout << std::endl;
}

int main() {
    Graph testGraph = loadTestGraph();
    Graph campusGraph = loadCampusGraph();

    performTest(testGraph, "Simple Graph");
    performTest(campusGraph, "Campus Graph");
}
