#include <graph.hpp>
#include <iostream>

std::vector<int> searchShortestPath(Graph &G, int start, int destination) {
    std::vector<bool> visited(G.n, false);
    std::vector<int> distance(G.n, INT_MAX), parent(G.n, -1);
    distance[start] = 0;
    parent[start] = -1;
    for (int i = 1; i <= G.n - 1; ++i) {
        int u, minDistance = INT_MAX;
        for (int i = 0; i < G.n; ++i)
            if (distance[i] < minDistance && visited[i] == false) {
                minDistance = distance[i];
                u = i;
            }
        visited[u] = true;
        for (auto e: G.e[u]) {
            int v = e.v; int w = e.w;
            if (visited[v] == false && distance[u] + w < distance[v]) {
                distance[v] = distance[u] + w;
                parent[v] = u;

            }
        }
    }
    std::vector<int> path;
    int u = destination;
    while (u != -1) {
        path.push_back(u);
        u = parent[u];
    }
    std::reverse(path.begin(), path.end());
    return path;
}


void performTest(Graph G, std::string graphName) {
    std::vector<int> path;
    path = searchShortestPath(G, 0, G.n - 1);
    std::cout << "Shortest Path From " << 0 <<  " to " << G.n - 1 << " on " << graphName << ": ";
    for (auto v: path)
        std::cout << v << " ";
    std::cout << std::endl;
}

int main() {
    Graph testGraph = loadTestGraph();
    Graph campusGraph = loadCampusGraph();

    performTest(testGraph, "Simple Graph");
    performTest(campusGraph, "Campus Graph");
}
