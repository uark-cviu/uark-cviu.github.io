#include <graph.hpp>
#include <iostream>

int main() {
    Graph G(4);
    G.insertEdge(0, 1, 2); G.insertEdge(0, 2, 4); G.insertEdge(0, 3, 5);
    G.insertEdge(1, 2, 1); G.insertEdge(2, 0, 4);
    G.insertEdge(2, 3, 1);

    int u = 0;
    for (int i = 0; i < G.e[u].size(); ++i) {
      int v = G.e[u][i].v;
      int w = G.e[u][i].w;
      std::cout << "u = " << u << ". v = " << v << ". w = " << w << "\n";
    }

}
