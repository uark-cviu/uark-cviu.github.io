#include <graph.hpp>
#include <iostream>

std::vector<Edge> constructMSTPrim(Graph G) {
    std::vector<Edge> MST;
    std::vector<bool> T(G.n, false);
    std::vector<int> distance(G.n, INT_MAX), parent(G.n, -1);
    T[0] = true;
    for (auto e: G.e[0]) {
        int v = e.v;  int w = e.w;
        distance[v] = w ;
        parent[v] = 0;
    }
    for (int i = 1; i <= G.n - 1; ++i) {
        int u, minDistance = INT_MAX;
        for (int i = 0; i < G.n; ++i)
            if (distance[i] < minDistance && T[i] == false)
                minDistance = distance[i], u = i;
        T[u] = true;
        MST.push_back(Edge(u, parent[u], distance[u]));
        for (auto e: G.e[u]) {
            int v = e.v;  int w = e.w;
             if (T[v] == false && w < distance[v])
                distance[v] = w, parent[v] = u;
        }
    }
    return MST;
}

void performTest(Graph G, std::string graphName) {
    std::vector<Edge> MST;
    MST = constructMSTPrim(G);
    int total = 0;
    for (auto e: MST)
        total += e.w;

    std::cout << "Total Cost of MST in " << graphName << ": " << total << std::endl;
    std::cout << "List of Edges in MST: " << std::endl;
    for (auto e: MST)
        std::cout << "(" << e.u << ", " << e.v << ", " << e.w << ") ";
    std::cout << std::endl;
}

int main() {
    Graph testGraph = loadTestGraph();
    Graph campusGraph = loadCampusGraph();

    performTest(testGraph, "Simple Graph");
    performTest(campusGraph, "Campus Graph");
}
