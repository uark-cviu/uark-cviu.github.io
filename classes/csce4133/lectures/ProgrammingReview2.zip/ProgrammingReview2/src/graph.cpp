#include <graph.hpp>
#include <cmath>
#include <map>
#include <fstream>

Edge::Edge() {

};

Edge::Edge(int u, int v, int w) {
    this->u = u;
    this->v = v;
    this->w = w;
}

Edge::Edge(const Edge &e) {
    this->u = e.u;
    this->v = e.v;
    this->w = e.w;
}

bool Edge::operator<(const Edge &second) {
    return this->w < second.w;
}

bool Edge::operator>(const Edge &second) {
    return this->w > second.w;
}

bool Edge::operator==(const Edge &second) {
    return this->w == second.w;
}

bool Edge::operator>=(const Edge &second) {
    return this->w >= second.w;
}

bool Edge::operator<=(const Edge &second) {
    return this->w <= second.w;
}

Graph::Graph(int n) {
    this->n = n;
    this->e = std::vector<std::vector<Edge> >(n, std::vector<Edge>());
}

Graph::~Graph(){
    this->e.clear();
}
void Graph::insertEdge(int u, int v, int w, bool directed) {
    this->e[u].push_back(Edge(u, v, w));
    if (not directed)
        this->e[v].push_back(Edge(v, u, w));
}

std::vector<Edge> Graph::exportEdges() {
    std::vector<Edge> edges;
    for (int u = 0; u < this->n; ++u) {
        for (int i = 0; i < this->e[u].size(); i += 1)
            edges.push_back(Edge(this->e[u][i])); 
    }
    return edges;
}

Graph loadTestGraph() {
    Graph G(6);
    G.insertEdge(0, 1, 1);
    G.insertEdge(1, 2, 2);
    G.insertEdge(1, 3, 3);
    G.insertEdge(2, 4, 4);
    G.insertEdge(4, 3, 5);
    G.insertEdge(4, 5, 6);
    return G;
}

Graph loadCampusGraph() {
    std::ifstream reader("assets/map_info.txt");
    int n, m;
    reader >> n >> m;
    std::map<std::string, int> name2index;
    std::map<int, std::string> index2name;
    std::vector<int> xs;
    std::vector<int> ys;
    for (int i = 0; i < n; ++i) {
        int index, x, y;
        std::string name;
        reader >> index >> name >> x >> y;
        xs.push_back(x);
        ys.push_back(y);
        name2index[name] = index;
        index2name[index] = name;
    }

    Graph G(n);

    for (int i = 0; i < m; ++i) {
        int u, v;
        reader >> u >> v;
        int dx = xs[u] - xs[v];
        int dy = ys[u] - ys[v];
        int w = (int)sqrt(dx * dx + dy * dy);
        G.insertEdge(u, v, w);
    }
    return G;
}
DisjointSet::DisjointSet(int n) {
    this->parent = std::vector<int>(n, -1);
}

int DisjointSet::find(int u) {
    if (this->parent[u] == -1)
        return u;
    else
        return this->parent[u] = this->find(parent[u]);
}

int DisjointSet::isOnSameSet(int u, int v) {
    return (this->find(u) == this->find(v)) ? 1 : 0;
}

void DisjointSet::join(int u, int v) {
    int pu = this->find(u);
    int pv = this->find(v);
    if (pu != pv)
        this->parent[pu] = pv;
}

template<class T>
void sort(std::vector<T> &array, int l, int r) {
    if (l >= r)
        return;
    int m = (l + r) >> 1;
    sort(array, l, m);
    sort(array, m + 1, r);
    std::vector<T> tmp;
    tmp.clear();
    int i = l;
    int j = m + 1;
    while (i <= m || j<= r) {
        if (i <= m && (j > r || array[i] < array[j])) {
            tmp.push_back(array[i]);
            ++i;
        }
        else {
            tmp.push_back(array[j]);
            ++j;
        }
    }
    for (int i = 0; i < tmp.size(); ++i)
        array[l+i] = tmp[i];
}

template void sort(std::vector<Edge> &array,  int l, int r);
template void sort(std::vector<int> &array,  int l, int r);

