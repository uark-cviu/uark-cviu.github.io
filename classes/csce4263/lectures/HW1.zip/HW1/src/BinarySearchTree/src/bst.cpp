#include <bst.hpp>
#include <stack>

Node::Node(int key, Node *left, Node *right) {
    // This is the constructor of Node with initialized key and next pointer
    // You do not need to modify this constructor
    this->key = key;
    this->left = left;
    this->right = right;;
}

Node::Node() {
    // This is an empty constructor
    // You do not need to modify this constructor
    this->key = 0;
    this->left = this->right = NULL;
}

Node::~Node() {
    // This an empty deconstructor
    // You do not need to modify this deconstuctor
}

BST::BST() {
    // This is an empty constructor
    // You do not need to modify this constructor
    this->root = NULL;
}

BST::~BST() {
    // This is the deconstructor used to release the current binary search tree
    // You do not need to modify this deconstructor

    Node *p = this->root;
    if (p == NULL)
        return;
    std::stack<Node*> stack;
    stack.push(p);
    while (!stack.empty()) {
        p = stack.top();
        stack.pop();
        if (p->left != NULL)
            stack.push(p->left);
        if (p->right != NULL)
            stack.push(p->right);
        p->left = p->right = NULL;
        delete p;
    }
}

int BST::insertNode(int key) {
    /*
     * This function will insert key into the binary search tree
     * Return 1 if the function the key is inserted in to the binary search tree
     */

    Node *p = this->root;
    // Your Code Here
}

int BST::deleteNode(int key) {
    /*
     * This function will delete key out of binary search tree if key exists
     * Return 1 if key is deleted successfully
     * Return 0 if the key does not exist
     */


    Node *p = this->root;
    // Your Code Here
    return 0;
}

int BST::searchNode(int key) {
    /*
     * This function will search for the key in the binary search tree
     * Return 1 if the key exists, otherwise return 0
     */

    Node *p = this->root;
    // Your Code Here

    return 0;
}

int BST::length() {
    /*
     * This function will return the length of binary search tree
     * Return the current number of keys in the binary search tree
     */

    Node *p = this->root;
    // Your Code Here
    return 0;

}


/* 
 * The code below is used to communicate with Python
 * You do not need to modify these codes
 */

void *createBST() {
    return new(std::nothrow) BST();
}

int insertNode(void *bst, int key) {
    BST* bst_ = reinterpret_cast<BST*>(bst);
    return bst_->insertNode(key);
}

int deleteNode(void* bst, int key) {
    BST* bst_ = reinterpret_cast<BST*>(bst);
    return bst_->deleteNode(key);
}


int searchNode(void* bst, int key) {
    BST* bst_ = reinterpret_cast<BST*>(bst);
    return bst_->searchNode(key);

}

void releaseBST(void* bst) {
    delete bst;
}

int length(void *bst) {
    BST* bst_ = reinterpret_cast<BST*>(bst);
    return bst_->length();
}
