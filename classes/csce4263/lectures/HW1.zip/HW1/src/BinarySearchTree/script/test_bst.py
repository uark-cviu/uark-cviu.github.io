import ctypes
import os

class BST:
    def __init__(self):
        self.libpath = "lib/libbst.so"
        if not os.path.exists(self.libpath):
            self.libpath = "../lib/libbst.so"

        assert os.path.exists(self.libpath), "The library does not exist. Did you compile your source code?"

        self.libpath = os.path.realpath(self.libpath)

        self.c_lib = ctypes.CDLL(self.libpath)

        # Create Binary Search Tree Function
        self.c_lib.createBST.restype = ctypes.c_void_p

        # Insert Node Function
        self.c_lib.insertNode.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self.c_lib.insertNode.restype  = ctypes.c_int

        # Delete Node Function
        self.c_lib.deleteNode.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self.c_lib.deleteNode.restype  = ctypes.c_int

        # Search Node Function
        self.c_lib.searchNode.argtypes = [ctypes.c_void_p, ctypes.c_int]
        self.c_lib.searchNode.restype  = ctypes.c_int

        # Length of Binary Search Tree Function
        self.c_lib.length.argtypes = [ctypes.c_void_p]
        self.c_lib.length.restype = ctypes.c_int

        # Release Binary Search tree Function
        self.c_lib.releaseBST.argtypes = [ctypes.c_void_p]

        self.BST = self.c_lib.createBST()

    def __del__(self):
        self.c_lib.releaseBST(self.BST)


    def insert(self, value):
        return self.c_lib.insertNode(self.BST, value)

    def delete(self, value):
        return self.c_lib.deleteNode(self.BST, value)

    def search(self, value):
        return self.c_lib.searchNode(self.BST, value)

    def length(self):
        return self.c_lib.length(self.BST)

if __name__ == "__main__":
    BST = BST()
    for value in range(1, 11):
        success = BST.insert(value)
        assert success == 1, "Insert %d to binary search tree unsuccessfully. Please check your implementation in C++!" % value
        print("Insert %d to binary search tree successfully" % value)
    
    success = BST.insert(10)
    assert success == 0, "Value = 10 has already existed in the binary search tree and should not be inserted. Please check your implementation in C++!" % value
    print("Insert %d to binary search tree unsuccessfully since it has already existed in the binary search tree" % 10)
    
    assert BST.search(5) == 1, "Value = 5 should exist in your binary search tree but you return 0. Please check your implementation in C++!"
    print("Value = 5 exists in your binary search tree")

    assert BST.search(15) == 0, "Value = 15 should not exist in your binary search tree but you return 1. Please check your implementation in C++!"
    print("Value = 15 does not exist in your binary search tree")

    length = BST.length()
    assert length == 10, "The current number of values in the binary search tree should be 10 but you return %. Please check your implementation in C++!" % length
    print("The current number of values in the binary search tree: %d" % length)

    assert BST.delete(5) == 1, "Value = 5 in your binary search tree should be deleted. Please check your implementation in C++!"
    print("You delete value = 5 out of your binary search tree successfully!")

    length = BST.length()
    assert length == 9, "The current number of values in the binary search tree should be 9 but you return %d. Please check your implementation in C++!" % length
    print("The current number of values in the binary search tree: %d" % length)


    assert BST.search(5) == 0, "Value = 5 should not exist in your binary search tree since you just delte it but you return 1. Please check your implementation in C++!"
    print("Value = 5 does not exist in your binary search tree since you just delete it")

