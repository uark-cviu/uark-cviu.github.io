#include <iostream>

struct Node {
    int key;
    Node *left;
    Node *right;
    Node(int key, Node *left = NULL, Node *right = NULL);
    Node();
    ~Node();
};

class BST {
    private:
        Node *root;
        int len = 0; // Can be used to store the length of the linked list 
    public:
        BST();
        ~BST();

        int insertNode(int key);
        int deleteNode(int key);
        int searchNode(int key);
        int length();
};

extern "C" {
    void* createBST();
    int insertNode(void* bst, int value);
    int deleteNode(void* bst, int value);
    int searchNode(void* bst, int value);
    int length(void* bst);
    void releaseBST(void* bst);
};





