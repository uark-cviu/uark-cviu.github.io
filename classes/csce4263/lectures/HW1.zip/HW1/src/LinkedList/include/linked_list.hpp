#include <iostream>

struct Node {
    int value;
    Node *next;
    Node(int value, Node *next = NULL);
    Node();
    ~Node();
};

class LinkedList {
    private:
        Node* header;
        int len = 0; // Can be used to store the length of the linked list 
    public:
        LinkedList();
        ~LinkedList();
        int insertNode(int value);
        int deleteNode(int value);
        int searchNode(int value);
        int length();
};


extern "C" {
    void* createLinkedList();
    int insertNode(void* linkedList, int value);
    int deleteNode(void* linkedList, int value);
    int searchNode(void* linkedList, int value);
    int length(void* linkedList);
    void releaseLinkedList(void* linkedList);
};



