#include <linked_list.hpp>

int main() {
    LinkedList linkList;

    for (int value = 1; value <= 10; ++value) {
        int success = linkList.insertNode(value);
        if (success != 1) {
            std::cout << "Insert " << value << " unsuccessfully. Please check your C++ implementation" << std::endl;
            return 0;
        } else {
            std::cout << "Insert " << value << " into the linked list." << std::endl;

        }
    }

    if (linkList.searchNode(5) != 1) {
        std::cout << "Value = 5 should exist in your linked list but you return 0. Please check your C++ implementation!" << std::endl;
        return 0;
    } else {
        std::cout << "Value = 5 exists in your linked list" << std::endl; 
    }
    
    if (linkList.searchNode(15) == 1) {
        std::cout << "Value = 15 should not exist in your linked list but you return 1. Please check your C++ implementation!" << std::endl;
        return 0;
    } else {
        std::cout << "Value = 15 does not exist in your linked list" << std::endl; 
    }

    int length = linkList.length() ;
    if (length != 10) {
        std::cout << "The current number of values in the linked list should be 10 but you return " << length << ". Please check your C++ implementation!" << std::endl;
        return 0;
    } else {
        std::cout << "There is " << length << " values in your linked list." << std::endl;
    }
    
    if (linkList.deleteNode(5) != 1) {
        std::cout << "Value = 5 in your linked list should be deleted. Please check your implementation in C++!" << std::endl;
        return 0;
    } else {
        std::cout << "You delete value = 5 out of your linked list successfully!" << std::endl;
    }

    length = linkList.length();
    if (length != 9) {
        std::cout << "The current number of values in the linked list should be 9 but you return " << length << ". Please check your C++ implementation!" << std::endl;
        return 0;
    } else {
        std::cout << "There is " << length << " values in your linked list." << std::endl;
    }

    
    if (linkList.searchNode(5) != 0) {
        std::cout << "Value = 5 should not exist in your linked list but you return 1. Please check your C++ implementation!" << std::endl;
        return 0;
    } else {
        std::cout << "Value = 5 does not exist in your linked list" << std::endl; 
    }

    std::cout << "You pass all the unit tests of the linked list. Note: Passing all the unit tests does not guarantee your implementation is 100% correct. You may check the logic of your code carefully before you submit your homework!" << std::endl;

}
