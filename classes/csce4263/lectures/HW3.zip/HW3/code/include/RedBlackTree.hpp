#pragma once

#include <iostream>
#include <vector>
#include <algorithm>

#include <cassert>
#include <iostream>

enum Color { RED, BLACK };

struct Node {
    int key;
    int value;      
    Color color;
    Node *left;
    Node *right;
    Node *parent;

    Node(int key, int value, Color color, Node *left=nullptr, Node *right=nullptr, Node *parent=nullptr)
        : key(key), value(value), color(color),
          left(left), right(right), parent(parent) {}

    ~Node() = default;
};

class RedBlackTree {
private:
    Node *root;

public:
    RedBlackTree();
    ~RedBlackTree();

    void insert(int key, int value);
    void remove(int key, int value);
    Node* findMinimum();

};



extern "C" {
    void* createRedBlackTree();
    void insertNode(void *tree, int vertex, int distance);
    void deleteNode(void *tree, int vertex, int distance);
    int getMinDistance(void *tree);
    int getMinVertex(void *tree);
    void releaseRedBlackTree(void *tree);
};
