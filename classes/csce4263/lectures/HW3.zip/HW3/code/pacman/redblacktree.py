import ctypes
import os

class RedBlackTree:
    def __init__(self):
        self.libpath = "lib/libredblacktree.so"
        if not os.path.exists(self.libpath):
            self.libpath = "../lib/libredblacktree.so"

        assert os.path.exists(self.libpath), "The library does not exist. Did you compile your source code?"

        self.libpath = os.path.realpath(self.libpath)

        self.c_lib = ctypes.CDLL(self.libpath)

        # Create Binary Search Tree Function
        self.c_lib.createRedBlackTree.restype = ctypes.c_void_p

        # Insert Node Function
        self.c_lib.insertNode.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
        #self.c_lib.insertNode.restype = ctypes.c_void_p

        # Delete Node Function
        self.c_lib.deleteNode.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
        #self.c_lib.deleteNode.restype = ctypes.c_void_p

        # Get Min Distance
        self.c_lib.getMinDistance.argtypes = [ctypes.c_void_p]
        self.c_lib.getMinDistance.restype = ctypes.c_int

        # Get Min Vertex
        self.c_lib.getMinVertex.argtypes = [ctypes.c_void_p]
        self.c_lib.getMinVertex.restype = ctypes.c_int

        # Release Binary Search tree Function
        self.c_lib.releaseRedBlackTree.argtypes = [ctypes.c_void_p]

        self.RedBlack = self.c_lib.createRedBlackTree()

    def __del__(self):
        print("delete tree")
        self.c_lib.releaseRedBlackTree(self.RedBlack)


    def insert(self, vertex, distance):
        #self.RedBlack =
        self.c_lib.insertNode(self.RedBlack, vertex, distance)

    def delete(self, vertex, distance):
        #self.RedBlack =
        self.c_lib.deleteNode(self.RedBlack, vertex, distance)

    def getMin(self):
        vertex = self.c_lib.getMinVertex(self.RedBlack)
        distance = self.c_lib.getMinDistance(self.RedBlack)
        return vertex, distance


if __name__ == "__main__":
    redblack = RedBlackTree()

