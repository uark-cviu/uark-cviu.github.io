#include <RedBlackTree.hpp>

RedBlackTree::RedBlackTree() {
    this->root = NULL;
}

RedBlackTree::~RedBlackTree() {
    // YOUR CODE HERE
}

void RedBlackTree::insert(int key, int value) {
    /*
        Given key and value, insert key and value into the red black tree.
        In this red-black tree 
                    parent
                    /    \
                left      right
        condition to be the left child: (left->key < parent->key) or (left->key == parent->key and left->value <= parent->value)
        otherwise, it will be the right child
    */
    // YOUR CODE HERE
}


void RedBlackTree::remove(int key, int value) {
   // YOUR CODE HERE
   /*
        Given key and value, remove key and value out of the red black tree.
        In this red-black tree 
                    parent
                    /    \
                left      right
        condition to be the left child: (left->key < parent->key) or (left->key == parent->key and left->value <= parent->value)
        otherwise, it will be the right child
    */
    // YOUR CODE HERE
}

Node* RedBlackTree::findMinimum() {
    // YOUR CODE HERE
    /*
        Return the node that contains the the minimum "key"
        In this red-black tree 
                    parent
                    /    \
                left      right
        condition to be the left child: (left->key < parent->key) or (left->key == parent->key and left->value <= parent->value)
        otherwise, it will be the right child
    */
    // YOUR CODE HERE
}



/*
 * This code below is used to communicate with Python
 * You do not need to modify these codes
 */

void* createRedBlackTree() {
    return new(std::nothrow) RedBlackTree();
}

void insertNode(void* tree, int vertex, int distance) {
    RedBlackTree* tree_ = reinterpret_cast<RedBlackTree*>(tree);
    tree_->insert(distance, vertex);

}

void deleteNode(void* tree, int vertex, int distance) {
    RedBlackTree* tree_ = reinterpret_cast<RedBlackTree*>(tree);
    tree_->remove(distance, vertex);
}

int getMinDistance(void* tree) {
    RedBlackTree* tree_ = reinterpret_cast<RedBlackTree*>(tree);
    return tree_->findMinimum()->key;
}

int getMinVertex(void* tree) {
    RedBlackTree* tree_ = reinterpret_cast<RedBlackTree*>(tree);
    return tree_->findMinimum()->value;
}

void releaseRedBlackTree(void* tree) {
   delete tree;  
}
