#pragma once

#include <iostream>
#include <vector>
#include <algorithm>

struct Node {
    Node *left;
    Node *right;
    int key;
    int vertex;
    int height;
    Node(int key, int vertex, int height, Node *left, Node *right);
    ~Node();
};

class AVLTree {
    private:
        Node *root;
        Node *null;

        void update(Node *p);
        int balanceFactor(Node *p);
        Node* rotateRight(Node *p);
        Node* rotateLeft(Node *p);
        Node* balance(Node *p);
        Node* insert(Node *p, int key, int vertex);
        Node* findMin(Node *p);
        Node* remove(Node *p, int key, int vertex); 
        void releaseTree(Node *p);
    public:
        AVLTree();
        ~AVLTree();

        void insertVertex(int vertex, int distance);

        void removeVertex(int vertex, int distance);
        
        int getMinDistance();

        int getMinVertex();
};

extern "C" {
    void* createAVLTree();
    void insertNode(void *tree, int vertex, int distance);
    void deleteNode(void *tree, int vertex, int distance);
    int getMinDistance(void *tree);
    int getMinVertex(void *tree);
    void releaseAVLTree(void *tree);
};
