#include <AVLTree.hpp>

Node::Node(int key, int vertex, int height, Node *left, Node *right) {
    /*
     * This is the Node constructor
     */

    this->key = key;
    this->vertex = vertex;
    this->height = height;
    this->left = left;
    this->right = right;
}

Node::~Node() {
    /* 
     * This is the Node deconstructor
     */

    // Pointer will be released in AVL Tree
    this->left = this->right = NULL;
}

AVLTree::AVLTree() {
    /* 
     * This is the AVL Tree constructor
     */

    // Create a dump null pointer for easy computation
    this->null = new Node(-1, -1, 0, NULL, NULL);
    this->null->left = this->null->right = this->null;

    // Create a dump root for easy intialization of AVL Tree 
    this->root = this->null; 
}

AVLTree::~AVLTree() {
    /*
     * This is the AVL Tree deconstructor
     */
   this->releaseTree(this->root);
   this->null->left = this->null->right = NULL;
   delete this->null;
}


void AVLTree::releaseTree(Node *p) {
    /*
     * This function will release the memory of the AVL Tree
     */
    if (p == this->null)
        return;
    this->releaseTree(p->left);
    this->releaseTree(p->right);
    delete p;
}

void AVLTree::update(Node *p) {
    /*
     *  This function updates the height of the current subtree p
     */
    if (p == this->null)
        return;
    p->height = std::max(p->left->height, p->right->height) + 1;
}

int AVLTree::balanceFactor(Node *p) {
    /*
     *  This function returns the difference of height 
     *  between the right subtree and the left subtree
     */

    // YOUR CODE HERE

}

Node* AVLTree::rotateRight(Node *p) {
    /*
     *  This function rotates node p to the right
     *  and returns a new replacement node
     */
    
    // YOUR CODE HERE
}

Node* AVLTree::rotateLeft(Node *p) {
    /*
     *  This function rotates node p to the left
     *  and returns a new replacement node
     */

    // YOUR CODE HERE
    
}

Node* AVLTree::balance(Node *p) {
    /*
     * This function balances the subtree p 
     * if the current subtree p is not balanced
     * and returns a new root of subtree p 
     */

    // YOUR CODE HERE
    
}


Node* AVLTree::insert(Node *p, int key, int vertex) {
    /*
     *  This function inserts a new key and vertex into the tree p
     *  and returns a new root of subtree p 
     */

    if (p == this->null) { // insert new node
        // YOUR CODE HERE 
    } else if (key <= p->key) { // Insert to the left
        // YOUR CODE HERE 
    } else {// Insert to the right 
        // YOUR CODE HERE
    }

    // Perform Balancing
    // YOUR CODE HERE
}

Node* AVLTree::findMin(Node *p) {
    /*
     * This function returns the node containing minimum key
     * of subtree p 
     */

    // YOUR CODE HERE 
}

Node* AVLTree::remove(Node *p, int key, int vertex) {
    /* 
     * This function deletes the node containing key and vertex in subtree p
     * and returns a new too of subtree p
     */

    if (p == this->null) { // key does not exists in a tree
        return p;
    } else if (key == p->key && vertex == p->vertex) { // Found and Remove
        // YOUR CODE HERE
    } else if (key <= p->key){ // Delete on the left
        // YOUR CODE HERE
    }
    else { // Delete on the right 
        // YOUR CODE HERE
    }

    // Perform Balancing
    // YOUR CODE HERE

}

void AVLTree::insertVertex(int vertex, int distance) {
    /*
     * This function inserts a new vertex and distance into the AVL Tree
     */

    this->root = this->insert(this->root, distance, vertex);
}

void AVLTree::removeVertex(int vertex, int distance) {
    /* 
     * This function remove a vertex and its distance out of the AVL Tree
     */

    this->root = this->remove(this->root, distance, vertex);
}

int AVLTree::getMinDistance() {
    /*
     * This function returns the current minimum distance
     */

    Node *min = this->findMin(this->root);
    return min->key;
}

int AVLTree::getMinVertex() {
    /*
     * This function returns the vertex containing the mininum distance 
     */

    Node *min = this->findMin(this->root);
    return min->vertex;
}



/*
 * This code below is used to communicate with Python
 * You do not need to modify these codes
 */

void* createAVLTree() {
    return new(std::nothrow) AVLTree();
}

void insertNode(void* tree, int vertex, int distance) {
    AVLTree* tree_ = reinterpret_cast<AVLTree*>(tree);
    tree_->insertVertex(vertex, distance);

}

void deleteNode(void* tree, int vertex, int distance) {
    AVLTree* tree_ = reinterpret_cast<AVLTree*>(tree);
    tree_->removeVertex(vertex, distance);
}

int getMinDistance(void* tree) {
    AVLTree* tree_ = reinterpret_cast<AVLTree*>(tree);
    return tree_->getMinDistance();
}

int getMinVertex(void* tree) {
    AVLTree* tree_ = reinterpret_cast<AVLTree*>(tree);
    return tree_->getMinVertex();
}

void releaseAVLTree(void* tree) {
   delete tree;  
}
